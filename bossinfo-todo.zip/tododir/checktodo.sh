#!/bin/bash
cd /root/tododir/
LOGFILE="/root/tododir/log-todo.txt"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" | tee -a $LOGFILE
}

while true; do
    if pgrep -f "python3 /root/tododir/todo.py" >/dev/null; then
        log "todo.py is running."
    else
        log "todo.py is not running. Restarting..."
        nohup python3 /root/tododir/todo.py 2>&1 | tail -n 30 -f > $LOGFILE &
    fi
    sleep 10  # 每200秒检测一次
done

